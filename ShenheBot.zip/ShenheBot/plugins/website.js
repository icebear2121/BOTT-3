let handler = async m => {

let krtu = `web`
m.reply(`
> http://youtube.com/@ZenssCuyy
`.trim()) 
}
handler.command = /^(web)$/i

module.exports = handler