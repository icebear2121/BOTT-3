- Kalo masalah sesi lu ambil di Sc sebelah karena sc ini tidak bisa scan session
- Scan qr ada di module readme main baca aja readme nya

- Free apikey
[Link](https://api.tiodevhost.my.id)

- Downloader api
[Link](https://ytdl.tiodevhost.my.id)
