# Security Policy

## Supported Versions

Current projects supported by hosting

| Version | Supported          |
| ------- | ------------------ |
| 1.1.1   | :x: EXPIRED        |
| 3.0     | ✔️  WORK           |         
| alpha   | :x: EXPIRED        |
| <3.1    | :x: EXPIRED        |

## Reporting a Vulnerability

> This script is vulnerable to being suspended from certain hosting so use a hosting with a friendly level of security.
> This script will continue to update until the gap for this bot will expire 
