## MD Sessions
> kalo mau pake sesi md maka gunakan main.js yang ada di link berikut
[`LINK`](https://github.com/BOTCAHX/RTXZY-MD/tree/v3.0/MD)

> Salin main.js tersebut lalu paste di main.js original 
